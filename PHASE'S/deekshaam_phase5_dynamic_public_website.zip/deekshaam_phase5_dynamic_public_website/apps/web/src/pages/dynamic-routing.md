# Dynamic Route Strategy

Routes:

/
/about
/programs
/programs/:slug
/news
/news/:slug
/events
/gallery
/contact

Content is resolved by slug from API.
