# Dynamic Public Website Architecture

Flow:

CMS Admin
   |
   v
Database
   |
   v
API Layer
   |
   v
Public Website


Frontend responsibility:
- Rendering
- User interaction
- Responsive presentation

Backend responsibility:
- Content delivery
- Permissions
- Data validation
