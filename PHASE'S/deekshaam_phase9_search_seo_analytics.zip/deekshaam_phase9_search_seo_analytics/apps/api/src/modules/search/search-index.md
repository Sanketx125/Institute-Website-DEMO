# Search Index Foundation

Indexed entities:

Page
Program
News
Event
Notice

Stored:
- title
- slug
- summary
- searchable content
- type
- updated date
