export const designTokens = {
  spacing: {},
  typography: {},
  breakpoints: {},
  radius: {}
};
