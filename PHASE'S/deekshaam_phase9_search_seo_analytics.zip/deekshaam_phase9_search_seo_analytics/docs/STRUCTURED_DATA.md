# Structured Data Foundation

Supported schemas:

- Organization
- Breadcrumbs
- Articles
- Events

Generated from approved CMS data.
