# Admin CMS Screens

Modules:

- Pages
- Menus
- Programs
- Departments
- News
- Events
- Notices
- Gallery
- Documents


Each screen uses common:
- Table view
- Search
- Filters
- Create/Edit form
- Publish controls
