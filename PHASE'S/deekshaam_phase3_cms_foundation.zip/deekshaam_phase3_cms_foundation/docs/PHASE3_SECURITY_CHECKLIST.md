Security checklist:

- Password hashing
- Protected admin routes
- Permission checks
- Upload validation
- Audit events
- Secret separation
- Session expiration
