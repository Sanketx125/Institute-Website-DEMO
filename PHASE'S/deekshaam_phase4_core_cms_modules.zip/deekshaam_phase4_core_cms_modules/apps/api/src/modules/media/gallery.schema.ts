export interface Gallery {
 id:string;
 title:string;
 items:string[];
 status:string;
}
