# Campus Map Experience

Features:

- Campus location display
- Directions link
- Mobile friendly map access

Rule:
Do not request browser location unless a feature requires it and consent is clear.
