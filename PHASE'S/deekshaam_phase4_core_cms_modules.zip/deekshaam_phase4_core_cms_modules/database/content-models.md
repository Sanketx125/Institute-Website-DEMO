# Content Models

## Pages
Fields:
- title
- slug
- sections
- seo metadata
- status

## Programs
Fields:
- name
- overview
- eligibility
- duration
- highlights
- brochure
- CTA

## News/Event/Notice
Fields:
- title
- slug
- cover image
- body
- publish date
- status

## Gallery
Fields:
- title
- media items
- category
