# Payment Flow

1 Create server order
2 Open checkout
3 Verify signature
4 Process webhook
5 Update final state
