# Deekshaam Website Phase 8 - Razorpay Payment Workflow

Scope: secure payment workflow foundation, order creation, verification, webhook handling, records and reconciliation.
