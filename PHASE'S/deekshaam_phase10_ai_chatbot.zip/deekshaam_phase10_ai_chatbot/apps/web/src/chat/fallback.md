# Human Fallback

When AI confidence is low:

- Show contact options
- Provide enquiry form link
- Suggest official sources
