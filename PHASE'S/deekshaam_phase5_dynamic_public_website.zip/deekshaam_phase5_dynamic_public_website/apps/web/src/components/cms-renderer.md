# CMS Renderer

Supported blocks:

- Hero
- Text
- Image
- Cards
- CTA
- Gallery
- FAQ

Unknown blocks should fail gracefully.
