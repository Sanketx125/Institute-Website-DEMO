# Public UI States

Every dynamic section supports:

Loading:
- skeleton UI

Empty:
- friendly placeholder

Error:
- retry/fallback message

Not Found:
- safe 404 page
