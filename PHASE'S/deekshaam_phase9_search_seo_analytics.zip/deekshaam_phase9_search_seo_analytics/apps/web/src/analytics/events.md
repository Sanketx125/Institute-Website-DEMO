# Analytics Events

Track approved conversions:

- Apply click
- Enquiry submission
- Call action
- Directions click
- Payment completion

Analytics provider remains configurable.
