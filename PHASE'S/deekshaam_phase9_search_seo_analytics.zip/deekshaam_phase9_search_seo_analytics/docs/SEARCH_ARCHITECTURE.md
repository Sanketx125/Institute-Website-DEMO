# Search Architecture

Content sources:

- Pages
- Programs
- News
- Events
- Notices

Flow:

User Query
 |
 v
Search API
 |
 v
Indexed Content
 |
 v
Results Page


Search should support:
- keyword matching
- filters
- relevance ordering
