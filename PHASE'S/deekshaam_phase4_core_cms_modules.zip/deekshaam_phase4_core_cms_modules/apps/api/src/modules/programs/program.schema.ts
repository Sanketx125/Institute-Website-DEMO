export interface Program {
 id:string;
 title:string;
 slug:string;
 overview:string;
 duration?:string;
 eligibility?:string;
 status:string;
}
