# Payment UI States

Initial, creating order, checkout, processing, success, failed, cancelled, retry.
