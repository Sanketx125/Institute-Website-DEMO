# Chat UI Flow

States:

- Welcome
- User question
- Processing
- Answer
- Unable to answer
- Contact support


Chat should never block normal website navigation.
