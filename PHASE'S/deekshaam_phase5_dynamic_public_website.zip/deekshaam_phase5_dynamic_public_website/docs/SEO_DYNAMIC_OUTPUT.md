# Dynamic SEO

CMS controlled:

- title
- description
- canonical URL
- social image
- structured metadata

Generated:
- sitemap
- robots rules
