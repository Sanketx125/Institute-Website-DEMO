# Lead Security

Controls:

- Server validation
- Rate limiting
- Spam protection
- Input sanitization
- Audit tracking
