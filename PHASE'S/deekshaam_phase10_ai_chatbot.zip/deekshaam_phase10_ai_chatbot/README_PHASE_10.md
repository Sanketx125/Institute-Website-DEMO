# Deekshaam Website Phase 10 - Optional AI Chatbot

Goal:
Add an optional AI assistant layer without coupling the core website to one AI provider.

Scope:
- Provider adapter
- Chat UI foundation
- Knowledge source preparation
- Controlled institute information scope
- Human fallback
- Security and monitoring

Core website must work without AI.
