export function requireRole(allowedRoles: string[]) {
  return function authorize(user: any) {
    if (!user || !allowedRoles.includes(user.role)) {
      throw new Error("Unauthorized");
    }
    return true;
  };
}
