# Lead Types

Supported:

- General enquiry
- Callback request
- Admission query
- Campus visit request

Each type can have additional fields.
