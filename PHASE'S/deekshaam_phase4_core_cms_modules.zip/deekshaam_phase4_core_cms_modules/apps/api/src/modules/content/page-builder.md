# Page Builder Foundation

Pages are assembled from reusable sections.

Example:

Homepage

Hero Section
+
Programs Section
+
Gallery Section
+
CTA Section


Avoid storing raw uncontrolled HTML.
