// Dynamic menu module foundation

Menu supports:
- ordering
- parent child structure
- visibility
- internal/external links
