// CMS content API boundary

export async function getPage(slug:string){
  // fetch dynamic page data
}

export async function getPrograms(){
  // fetch programs
}

export async function getNews(){
  // fetch news/events
}
