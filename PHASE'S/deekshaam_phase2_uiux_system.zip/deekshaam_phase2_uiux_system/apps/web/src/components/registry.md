# Component Registry

Layout:
- PageShell
- Container
- Header
- Footer

Content:
- HeroSection
- ProgramCard
- NewsCard
- GalleryCard

Interaction:
- FormField
- Modal
- Alert
- Loader
