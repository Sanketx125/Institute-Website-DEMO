# SEO Architecture

CMS
 |
 v
Metadata Service
 |
 v
Public Pages

Managed:
- title
- description
- canonical URL
- social image
- structured data


Generated:
- sitemap.xml
- robots.txt
