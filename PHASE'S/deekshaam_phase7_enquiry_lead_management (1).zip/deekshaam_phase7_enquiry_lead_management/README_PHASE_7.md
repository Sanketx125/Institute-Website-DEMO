# Deekshaam Website Phase 7 - Enquiry, Query & Campus Visit Management

Goal:
Create a complete lead management workflow for website enquiries.

Scope:
- General enquiry forms
- Callback requests
- Admission queries
- Campus visit requests
- Admin lead inbox
- Lead lifecycle tracking
- Search/filter/export foundation
- Spam protection

Not included:
- CRM replacement
- WhatsApp/SMS automation provider integration
