# AI Guardrails

Rules:

- Rate limiting
- Usage monitoring
- No secret exposure
- Safe fallback messages
- Human handoff option
