# AI Chatbot Architecture

User
 |
 v
Chat Interface
 |
 v
AI Adapter Layer
 |
 +--> Provider A
 +--> Provider B
 |
 v
Knowledge Retrieval
 |
 v
Response


Provider must be replaceable.
Business logic should not depend on one AI vendor.
