# Lead Data Model

Lead:
- id
- type
- name
- email
- phone
- interested_program
- message
- source_page
- status
- assigned_to
- created_at
- updated_at


Lead Status History:
- lead_id
- old_status
- new_status
- changed_by
- timestamp
