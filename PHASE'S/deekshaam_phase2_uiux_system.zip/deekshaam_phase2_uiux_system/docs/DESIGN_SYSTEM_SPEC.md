# Design System Specification

Foundation:
- Typography
- Spacing
- Containers
- Buttons
- Cards
- Image rules

Reusable Components:
- Header
- Navigation
- Footer
- Hero
- Section headers
- Cards
- CTA strips
- Accordions
- Tabs
- Breadcrumbs
- Forms
- Modals
- Alerts
- Loaders
- Empty states

Implementation rule:
Build mobile first and extend to desktop.
