# Payment Security

Secrets remain server-side. Verify signatures and webhook authenticity. Prevent duplicate processing.
