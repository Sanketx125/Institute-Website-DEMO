# CMS Architecture

Content flow:

Admin Panel
    |
    v
CMS API
    |
    v
Database
    |
    v
Public Website


Every content module follows:
- Create
- Edit
- Draft
- Review
- Publish
- Archive

Shared fields:
id
title
slug
status
created_by
updated_by
created_at
updated_at
published_at
