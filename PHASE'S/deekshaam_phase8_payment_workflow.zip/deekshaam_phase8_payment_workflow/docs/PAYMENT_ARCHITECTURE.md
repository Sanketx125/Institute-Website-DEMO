# Payment Architecture

User -> Backend Order Creation -> Razorpay Checkout -> Server Verification -> Webhook -> Database.
Frontend callbacks are not trusted as final payment proof.
