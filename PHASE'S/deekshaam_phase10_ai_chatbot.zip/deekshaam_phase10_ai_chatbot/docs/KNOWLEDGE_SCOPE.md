# Knowledge Scope

Initial approved sources:

- Website content
- Programs
- Admissions FAQ
- Notices
- Contact information


Avoid unrestricted answers.
Unknown questions should redirect users to official contact channels.
