# Admission Architecture

Applicant -> Application Form -> API Validation -> Database -> Admin Review.
Server remains the source of truth.
