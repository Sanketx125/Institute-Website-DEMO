# Provider Adapter

Interface should support:

- send message
- retrieve context
- return response
- handle errors


API keys remain server-side.
