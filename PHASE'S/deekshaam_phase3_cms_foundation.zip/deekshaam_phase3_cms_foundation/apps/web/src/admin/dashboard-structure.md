# Admin Dashboard

Sections:

- Dashboard
- Site Settings
- Media Library
- Content Management
- Users/Roles
- Audit Logs

Navigation visibility depends on role permissions.
