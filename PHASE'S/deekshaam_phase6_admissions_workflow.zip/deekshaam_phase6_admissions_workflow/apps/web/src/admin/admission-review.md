# Admin Review

List applications, search, filter, review documents, update status, view history.
