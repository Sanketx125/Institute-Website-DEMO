export interface MediaAsset {
  id: string;
  filename: string;
  url: string;
  type: string;
  altText?: string;
  uploadedBy: string;
}
