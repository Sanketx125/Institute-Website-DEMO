# Admin Lead Inbox

Features:

- Lead list
- Search
- Filters
- Lead detail
- Notes
- Status update
- Assignment
- Export
