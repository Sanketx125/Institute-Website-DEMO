export const apiFoundation = {
  name: 'deekshaam-api',
  phase: 1,
  status: 'foundation-ready'
};
