# Payment Model

Fields: id, purpose, application_id, order_id, payment_id, amount, status, timestamps.
Statuses: CREATED, PENDING, SUCCESS, FAILED, CANCELLED.
