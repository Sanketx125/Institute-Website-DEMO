# Applicant Journey

Select program -> Fill form -> Upload documents -> Submit -> Reference number -> Track status.
