# Public Lead Forms

Common components:

- Name field
- Contact field
- Program selector
- Message field
- Consent checkbox
- Submit action


States:

- Initial
- Validating
- Submitting
- Success
- Error
