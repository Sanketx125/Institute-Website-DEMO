Database migration folder reserved for PostgreSQL schema migrations.
Initial modules planned:
- users
- roles
- site_settings
- media
- audit_logs
