# Lead Workflow Architecture

Public User
    |
    v
Lead Form
    |
    v
API Validation
    |
    v
Lead Database
    |
    v
Admin Lead Inbox


Server remains source of truth.
