export interface SiteSettings {
  instituteName: string;
  logo?: string;
  address?: string;
  phone?: string;
  email?: string;
  socialLinks?: Record<string,string>;
  seoDefaults?: Record<string,string>;
}
