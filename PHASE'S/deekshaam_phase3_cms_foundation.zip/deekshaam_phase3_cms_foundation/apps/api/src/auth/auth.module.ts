// Authentication module foundation
// Handles login, session/token lifecycle and authorization boundary

export const AuthModule = {
  name: "auth"
};
