# Admission Data Model

Applications, Documents and Status History tables.
